echo running-tomcat-pre-install

cd /users/cgc/cwb/{{environment}}/tomcat/tc-cwb1/webapps
rm -rf api#cmp##*

date >> /tmp/pre-install.log
chmod 644 /tmp/pre-install.log