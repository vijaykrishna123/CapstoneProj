package com.capgroup.digital.ce.cmp.exceptions;

/**
 * Last modified date: Oct 2, 2018
 * 
 * @author CONPASK
 * 
 */
public class PercolateGatewayException extends RuntimeException {

  private static final long serialVersionUID = -6515169052551942374L;

  public PercolateGatewayException(final String message) {
    super(message);
  }

  public PercolateGatewayException(final Throwable cause) {
    super(cause);
  }

  public PercolateGatewayException(final String message, final Throwable cause) {
    super(message, cause);
  }

  public PercolateGatewayException(final String message, final Throwable cause,
      final boolean enableSuppression, final boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }
}
