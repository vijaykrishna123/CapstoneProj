package com.capgroup.digital.ce.cmp.dto;

import java.io.Serializable;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WipFolderRequest implements Serializable {

  private static final long serialVersionUID = -5347545577612685690L;

  @JsonProperty("year")
  protected String year;

  @JsonProperty("pod")
  protected String pod;

  @JsonProperty("percolateId")
  protected String percolateId;

  @JsonProperty("assignmentName")
  protected String assignmentName;

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
  }
  
  public boolean isEmpty() {
    return (this.year.isEmpty() || this.pod.isEmpty() || this.percolateId.isEmpty() || this.assignmentName.isEmpty());
  }
  
  public boolean isNull() {
    return (this.year == null || this.pod == null || this.percolateId == null || this.assignmentName == null);
  }

  public String getYear() {
    return year;
  }

  public void setYear(String year) {
    this.year = year;
  }

  public String getPod() {
    return pod;
  }

  public void setPod(String pod) {
    this.pod = pod;
  }

  public String getPercolateId() {
    return percolateId;
  }

  public void setPercolateId(String percolateId) {
    this.percolateId = percolateId;
  }

  public String getAssignmentName() {
    return assignmentName;
  }

  public void setAssignmentName(String assignmentName) {
    this.assignmentName = assignmentName;
  }
  
}

