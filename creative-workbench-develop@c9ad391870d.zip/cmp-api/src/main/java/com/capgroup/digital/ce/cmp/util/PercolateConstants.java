package com.capgroup.digital.ce.cmp.util;

/**
 * Last modified date: Sep 21, 2018
 * 
 * @author CONPASK
 * 
 */
public final class PercolateConstants {

  // Parameter constants
  public static final String ASSIGNEE_IDS = "assignee_ids";
  public static final String ASSIGNMENT_STATUSES = "assignment_statuses";
  public static final String EXTEND_SCOPES = "extend_scopes";

  public static final String SEARCH_QUERY = "search_query";

  public static final String SCHEMA_ID = "schema_id";

  // Id prefix constants
  public static final String USER = "user:";

  // general
  public static final String ASSIGNED = "assigned";

  // Object types
  public static final String TERM = "term";
  public static final String TEXT_AREA = "textarea";
  public static final String SELECT = "select";
  public static final String TEXT = "text";

  private PercolateConstants() {}

}
