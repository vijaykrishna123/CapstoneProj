package com.capgroup.digital.ce.cmp.edam;

import javax.validation.constraints.NotNull;
import com.percolate.sdk.api.utils.RetrofitApiFactory;
import retrofit2.Call;

public class EdamWipRequest {

  private EdamService service;

  public EdamWipRequest(@NotNull EdamApi context) {
    this.service = new RetrofitApiFactory(context).getService(EdamService.class);
  }


  public Call<EdamWipDataResponse> create(@NotNull final EdamWipData wipData, String csrfToken) {
    return service.create(wipData, csrfToken);
  }

  public Call<EdamCsrfToken> fetchCsrfToken(String edamCsrfTokenKey) {
    return service.fetchCsrfToken("*", edamCsrfTokenKey);
  }
}
