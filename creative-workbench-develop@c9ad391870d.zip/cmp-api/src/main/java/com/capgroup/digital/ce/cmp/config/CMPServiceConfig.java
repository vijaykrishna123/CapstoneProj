package com.capgroup.digital.ce.cmp.config;

import java.util.Collections;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.capgroup.digital.ce.cmp.edam.EdamApi;
import com.capgroup.digital.ce.cmp.edam.EdamServer;
import com.google.common.base.Predicates;
import com.percolate.sdk.api.PercolateApi;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

/**
 * Last modified date: Sep 21, 2018
 * 
 * @author CONPASK
 * 
 */
@Configuration
public class CMPServiceConfig {


  private CyberArkService data;

  private static final Logger logger = LogManager.getLogger(CMPServiceConfig.class);

  @Value("${cyberArk.enabled}")
  boolean cyberArkEnabled;

  @Value("${cg.proxyEnabled}")
  boolean proxyEnabled;

  @Value("${edam.baseUrl}")
  String baseUrl;

  @Value("${cyberArk.percolate.accName}")
  public String percolateCyberArkAccName;

  @Value("${cyberArk.edambasicauth.accName}")
  public String edamBasicAuthCyberArkAccName;

  public CMPServiceConfig(CyberArkService data) {
    this.data = data;
  }

  @Bean(name = "percolateApi")
  public PercolateApi getPercolateApi() {

    String percolateApiKey = null;

    logger.debug("Proxy Enabled: " + proxyEnabled);
    logger.debug("CyberArk Enabled: " + cyberArkEnabled);

    if (cyberArkEnabled)
      percolateApiKey = data.getKeyFromCyberArk(percolateCyberArkAccName, data.zone, data.env, data.resInstance,
          data.resAddress, data.technology, data.cgId);

    final PercolateApi percolateApi = new PercolateApi(percolateApiKey);
    percolateApi.getSelectedServer()
                .setEnableLocalProxy(proxyEnabled);
    return percolateApi;
  }

  @Bean(name = "edamApi")
  public EdamApi getEdamApi() {
    String edamBasicAuthKey = null;

    if (cyberArkEnabled)
      edamBasicAuthKey = data.getKeyFromCyberArk(edamBasicAuthCyberArkAccName, data.zone, data.env, data.resInstance,
          data.resAddress, data.technology, data.cgId);
    return new EdamApi(edamBasicAuthKey, new EdamServer("https", baseUrl, true));
  }


  @Bean
  public Docket api() {
    return new Docket(DocumentationType.SWAGGER_2).select()
                                                  .apis(RequestHandlerSelectors.any())
                                                  .paths(Predicates.not(PathSelectors.regex("/error.*")))
                                                  .build()
                                                  .apiInfo(apiInfo());
  }

  private ApiInfo apiInfo() {
    return new ApiInfo("CMP Service", "CMP-APIs to interact with Percolate", "1.0", null, null, null, null, Collections
                                                                                                                       .emptyList());
  }
}
