package com.capgroup.digital.ce.cmp.services;

import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.capgroup.digital.ce.cmp.controllers.CMPController;
import com.capgroup.digital.ce.cmp.dto.MetaData;
import com.capgroup.digital.ce.cmp.dto.Post;
import com.capgroup.digital.ce.cmp.dto.PostData;
import com.capgroup.digital.ce.cmp.dto.TaxonomyMapping;
import com.capgroup.digital.ce.cmp.dto.Transition;
import com.capgroup.digital.ce.cmp.dto.WipFolderRequest;
import com.capgroup.digital.ce.cmp.edam.EdamCsrfToken;
import com.capgroup.digital.ce.cmp.edam.EdamGateway;
import com.capgroup.digital.ce.cmp.edam.EdamWipData;
import com.capgroup.digital.ce.cmp.edam.EdamWipDataResponse;
import com.capgroup.digital.ce.cmp.edam.WipFolder;
import com.capgroup.digital.ce.cmp.exceptions.CMPException;
import com.capgroup.digital.ce.cmp.repositories.TaxonomyRepository;
import com.capgroup.digital.ce.cmp.util.CMPContstants;
import com.capgroup.digital.ce.cmp.util.PercolateConstants;
import com.percolate.sdk.api.request.license.LicenseV5Params;
import com.percolate.sdk.api.request.metadata.MetadataParams;
import com.percolate.sdk.api.request.post.PostGetParams;
import com.percolate.sdk.api.request.post.PostListParams;
import com.percolate.sdk.api.request.schema.SchemasListParams;
import com.percolate.sdk.api.request.terms.TermsParams;
import com.percolate.sdk.api.request.users.UsersParams;
import com.percolate.sdk.api.request.workflow.WorkflowStepsParams;
import com.percolate.sdk.dto.ChannelV5;
import com.percolate.sdk.dto.LicenseV5;
import com.percolate.sdk.dto.MetadataItem;
import com.percolate.sdk.dto.PostV5;
import com.percolate.sdk.dto.PostV5Data;
import com.percolate.sdk.dto.PostV5Include;
import com.percolate.sdk.dto.PostsV5;
import com.percolate.sdk.dto.ProductionWorkflow;
import com.percolate.sdk.dto.ProductionWorkflowStep;
import com.percolate.sdk.dto.Schema;
import com.percolate.sdk.dto.SchemaField;
import com.percolate.sdk.dto.User;
import com.percolate.sdk.dto.WorkflowStepData;
import com.percolate.sdk.dto.WorkflowTransition;
import com.percolate.sdk.enums.PostIncludeType;
import com.percolate.sdk.enums.SchemaType;


/**
 * Last modified date: Sep 21, 2018
 * 
 * @author CONPASK
 * 
 */
@Service
public class CMPServiceImpl implements CMPService {

  private static final Logger logger = LogManager.getLogger(CMPController.class);
  private final PercolateGateway percolateGateway;
  private final TaxonomyRepository taxonomyRepository;
  private final EdamGateway edamGateway;

  @Value("${percolate.license}")
  private String license;

  @Value("${percolate.customField.flag}")
  private String customFieldFlag;

  @Value("${percolate.customField.cwbUrl}")
  private String customFieldCWBUrl;

  @Value("${percolate.customField.workfrontJobId}")
  private String workfrontJobId;

  @Value("${cwb.baseUrl}")
  private String cwbBaseUrl;

  @Value("${percolate.baseUrl}")
  private String percolateBaseUrl;

  @Value("${percolate.tenant}")
  private String tenant;

  @Value("${percolate.customField.cgWriter}")
  private String cgWriter;

  @Value("${percolate.customField.wipUrl}")
  private String customFieldWIPUrl;

  @Value("${edam.baseUrl}")
  private String edamUrl;


  @Autowired
  public CMPServiceImpl(final PercolateGateway percolateGateway, final TaxonomyRepository taxonomyRepository,
      final EdamGateway edamGateway) {
    this.percolateGateway = percolateGateway;
    this.taxonomyRepository = taxonomyRepository;
    this.edamGateway = edamGateway;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.capgroup.digital.ce.cmp.services.CMPService#getAssignments(java.lang.String)
   */
  @Override
  public List<Post> getAssignments(final String search) {

    // final String userId = getUserId(search);

    final PostListParams postListParams = new PostListParams();
    postListParams.scopeIds(Arrays.asList(license));
    postListParams.include(Arrays.asList(PostIncludeType.PRODUCTION_WORKFLOW_ID, PostIncludeType.CHANNEL_ID,
        PostIncludeType.SCHEMA_ID));
    /*
     * postListParams.getParams() .put(PercolateConstants.ASSIGNEE_IDS, PercolateConstants.USER +
     * userId); postListParams.getParams() .put(PercolateConstants.ASSIGNMENT_STATUSES,
     * PercolateConstants.ASSIGNED);
     */

    getMetadataSchema(getAllContentMetadata(), cgWriter).ifPresent(schema -> {
      postListParams.getParams()
                    .put("metadata." + schema.getId() + "." + getMetadataSchemaKey(schema, cgWriter), search);
    });
    postListParams.getParams()
                  .put(PercolateConstants.EXTEND_SCOPES, "true");

    final PostsV5 postsV5 = percolateGateway.listPost(postListParams);
    final List<PostV5Data> postList = Optional.ofNullable(postsV5.getData())
                                              .orElse(Collections.emptyList());

    logger.debug("No of assigned contents for the User:" + search + " is " + postList.size());

    if (postList.isEmpty())
      return Collections.emptyList();

    final Optional<PostV5Include> include = Optional.ofNullable(postsV5.getInclude());
    final List<ChannelV5> channels = include.map(PostV5Include::getChannel)
                                            .orElse(Collections.emptyList());
    final List<Schema> schemas = include.map(PostV5Include::getSchema)
                                        .orElse(Collections.emptyList());
    final List<ProductionWorkflow> workflows = include.map(PostV5Include::getProductionWorkflow)
                                                      .orElse(Collections.emptyList());

    final List<WorkflowStepData> stepData = getCurrentWorkflowSteps(postList.stream()
                                                                            .filter(cmpPost -> cmpPost
                                                                                                      .getProductionWorkflowId() != null)
                                                                            .map(PostV5Data::getId)
                                                                            .collect(toList()));

    final List<LicenseV5> licenses = percolateGateway.listLicenses(new LicenseV5Params(postList.stream()
                                                                                               .map(
                                                                                                   PostV5Data::getScopeId)
                                                                                               .collect(toList())));
    final Function<PostV5Data, Post> populatePost = post -> {
      final Post assignment = new Post();
      assignment.setId(post.getId());
      assignment.setTitle(post.getName());
      assignment.setLiveAt(post.getLiveAt());
      Optional.ofNullable(post.getProductionWorkflowId())
              .ifPresent(workflowId -> {
                final List<ProductionWorkflowStep> steps = filterWorkflowStepsById(workflows, workflowId);
                final WorkflowStepData currentStep = getWorkflowStepData(post.getId(), stepData);
                final String key = currentStep.getProductionWorkflowStepKey();
                assignment.setAvailableStatus(getAvailableTransitionNames(steps, currentStep.getPossibleTransitionIds(),
                    stepData));
                final String currentStatus = filterWorkflowStepByKey(steps, key);
                assignment.setCurrentStatus(currentStatus);
                assignment.getAvailableStatus()
                          .put(currentStatus, currentStep.getId());
              });
      assignment.setChannel(filterChannelById(channels, post.getChannelId()));
      assignment.setTemplate(filterSchemaById(schemas, post.getSchemaId()));
      assignment.setTeam(filterTeamById(licenses, post.getScopeId()));
      return assignment;
    };

    return postList.parallelStream()
                   .map(populatePost)
                   .collect(toList());
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.capgroup.digital.ce.cmp.services.CMPService#getContent(java.lang.String)
   */
  @Override
  public PostData getContent(final String postId) {
    final PostData content = new PostData();
    final PostGetParams postGetParams = new PostGetParams(postId);
    postGetParams.include(Arrays.asList(PostIncludeType.SCHEMA_ID));

    final PostV5 post = percolateGateway.getPost(postGetParams);
    final PostV5Data data = Optional.ofNullable(post.getData())
                                    .orElseThrow(() -> new CMPException("Post Data object is Null"));
    content.setId(data.getId());
    content.setName(data.getName());
    content.setCreatedAt(data.getCreatedAt());
    final Map<String, Object> metadata = fetchMetaData(postId);
    content.setMetaData(metadata);
    content.setTaxonomy(getTaxonomyMappings(metadata));
    content.setPercolateUrl(percolateBaseUrl + tenant + "/posts/" + postId);
    content.setTemplate(filterSchemaById(post.getInclude()
                                             .getSchema(), post.getData()
                                                               .getSchemaId()));

    Optional.ofNullable(post.getInclude())
            .ifPresent(include -> getMetadataSchema(include.getSchema(), workfrontJobId).ifPresent(schema -> {
              final String workfrontId = data.getExt()
                                             .get(getMetadataSchemaKey(schema, workfrontJobId))
                                             .toString();
              if (!Strings.isBlank(workfrontId))
                metadata.put(workfrontJobId, workfrontId);
            }));
    logger.info("GET posts/" + postId + " is complete");
    return content;
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.capgroup.digital.ce.cmp.services.CMPService#addCWBUrl()
   */
  @Override
  public void addCWBUrl() {

    getMetadataSchema(getAllContentMetadata(), customFieldFlag).ifPresent(schema -> {
      final List<PostV5Data> postList = getFilteredContents(schema);

      if (!postList.isEmpty()) {

        final List<String> postIds = postList.stream()
                                             .map(PostV5Data::getId)
                                             .collect(toList());
        logger.info("posts to update:" + postIds);

        updatePostWithCWBUrl(postIds, schema);


      } else {
        logger.info("No posts to update.");
      }
    });
  }


  /**
   * Get list of CMP Post data filtered by given schema
   * 
   * @param schema - CMP Schema object
   * @return List of CMP Post data object
   */
  public List<PostV5Data> getFilteredContents(final Schema schema) {

    final PostListParams postListParams = new PostListParams();
    postListParams.scopeIds(Arrays.asList(license));
    postListParams.getParams()
                  .put(PercolateConstants.ASSIGNMENT_STATUSES, PercolateConstants.ASSIGNED);
    postListParams.getParams()
                  .put(PercolateConstants.EXTEND_SCOPES, "true");
    postListParams.getParams()
                  .put("metadata." + schema.getId() + "." + getMetadataSchemaKey(schema, customFieldFlag),
                      CMPContstants.CWB_LINKED_FLAG_NO);

    final List<PostV5Data> postList = Optional.ofNullable(percolateGateway.listPost(postListParams)
                                                                          .getData())
                                              .orElse(Collections.emptyList());
    logger.debug("No of posts based on the filter:" + postList.size());

    return postList;
  }

  /**
   * This method is to update the CWBUrl in CMP
   * 
   * @param postIds - list of post ids to update
   * @param schema - schema object used to filter the CMP posts
   */
  public void updatePostWithCWBUrl(final List<String> postIds, final Schema schema) {

    final List<MetadataItem> metadataItems = extractMetadataForPost(postIds, schema);

    final String cwbUrlKey = getMetadataSchemaKey(schema, customFieldCWBUrl);
    final String cwbUrlFlag = getMetadataSchemaKey(schema, customFieldFlag);

    metadataItems.forEach(metdadataItem -> {

      final LinkedHashMap<String, Object> extMap = metdadataItem.getExt();
      extMap.put(cwbUrlKey, cwbBaseUrl + metdadataItem.getObjectId());
      extMap.put(cwbUrlFlag, CMPContstants.CWB_LINKED_FLAG_YES);

      percolateGateway.updateMetadata(metdadataItem);
    });
  }


  /**
   * Method for extracting metadata for the post
   * 
   * @param postIds
   * @param schema
   * @return
   */
  private List<MetadataItem> extractMetadataForPost(final List<String> postIds, final Schema schema) {
    final MetadataParams metadataParams = new MetadataParams();
    metadataParams.objectIds(postIds);
    metadataParams.getParams()
                  .put(PercolateConstants.SCHEMA_ID, schema.getId());

    final List<MetadataItem> metadataItems = percolateGateway.listMetadata(metadataParams);
    logger.debug("Metadata to update:" + metadataItems.size());
    return metadataItems;
  }

  /**
   * Method for updating WIP link in percolate
   * 
   * @param postIds
   * @param schema
   * @param wipContentToUpdate
   */
  public void updatePostWithWIPUrl(final List<String> postIds, final Schema schema,
      Map<String, String> wipContentToUpdate) {

    final List<MetadataItem> metadataItems = extractMetadataForPost(postIds, schema);

    final String wipUrlKey = getMetadataSchemaKey(schema, customFieldWIPUrl);

    metadataItems.forEach(metdadataItem -> {

      final LinkedHashMap<String, Object> extMap = metdadataItem.getExt();
      extMap.put(wipUrlKey, wipContentToUpdate.get(metdadataItem.getObjectId()));

      percolateGateway.updateMetadata(metdadataItem);
    });

  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.capgroup.digital.ce.cmp.services.CMPService#transitionAssignment(com.capgroup.digital.ce.
   * cmp. dto.Transition)
   */
  @Override
  public void transitionAssignment(final Transition transition) {
    final WorkflowTransition workflowTransition = new WorkflowTransition();
    workflowTransition.setFromObjectStepId(transition.getFromStatus());
    workflowTransition.setToObjectStepId(transition.getToStatus());
    percolateGateway.transitAssignment(workflowTransition);
  }

  /**
   * This method is used to get the metadata schema of customFields
   * 
   * @return Schema
   */
  protected Optional<Schema> getMetadataSchema(final List<Schema> schemas, final String label) {
    return schemas.stream()
                  .filter(schema -> schema.getFields()
                                          .stream()
                                          .anyMatch(field -> field.getLabel()
                                                                  .equalsIgnoreCase(label)))
                  .findFirst();
  }

  /**
   * Get CMP User id for the given user email id
   * 
   * @param search - user email id
   * @return CMP user id
   */
  protected String getUserId(final String search) {

    final UsersParams usersParams = new UsersParams();
    usersParams.getParams()
               .put(PercolateConstants.SEARCH_QUERY, search);
    final List<User> userList = percolateGateway.listUser(usersParams);
    if (userList.isEmpty())
      throw new CMPException("No users found for: " + search);
    else if (userList.size() > 1)
      throw new CMPException(userList.size() + " users found for : " + search);

    // based on the above code we made sure userList size must be 1
    final String userId = userList.get(0)
                                  .getId();
    logger.debug("UserId : " + userId);

    return userId;
  }

  /**
   * finds the label of the metadata
   * 
   * @param schema
   * @param label
   * @return
   */
  protected String getMetadataSchemaKey(final Schema schema, final String label) {
    final SchemaField field = schema.getFields()
                                    .stream()
                                    .filter(f -> f.getLabel()
                                                  .equalsIgnoreCase(label))
                                    .findFirst()
                                    .orElseThrow(() -> new CMPException("Metadata Schema key doesn't exist:" + label));

    logger.debug("Schema Key for Label '" + label + "' is:" + field.getKey());

    return field.getKey();
  }

  /**
   * Gets Schema of all the Custom field metadata
   * 
   * @return
   */
  protected List<Schema> getAllContentMetadata() {
    final SchemasListParams schemasListParams = new SchemasListParams();
    schemasListParams.type(SchemaType.METADATA);
    schemasListParams.scopeIds(Arrays.asList(license));
    schemasListParams.getParams()
                     .put(PercolateConstants.EXTEND_SCOPES, "true");

    final List<Schema> schemaList = percolateGateway.listSchema(schemasListParams);
    logger.debug("Total No of Metadata Schema received:" + schemaList.size());

    return schemaList;
  }

  /**
   * Fetches the required metadata of the given post
   * 
   * @param postId - percolate post id
   * @return meta data as Map
   */
  @SuppressWarnings("unchecked")
  protected Map<String, Object> fetchMetaData(final String postId) {

    final MetadataParams metadataParams = new MetadataParams();
    metadataParams.objectIds(Arrays.asList(postId));

    final List<MetadataItem> metadataItems = percolateGateway.listMetadata(metadataParams);
    logger.debug("Metadata set of " + postId + " is " + metadataItems.size());

    final List<String> schemaIds = metadataItems.stream()
                                                .map(MetadataItem::getSchemaId)
                                                .collect(toList());

    final List<Schema> schemaList = new ArrayList<>();
    if (!schemaIds.isEmpty()) {
      final SchemasListParams schemasListParams = new SchemasListParams();
      schemasListParams.ids(schemaIds);

      schemaList.addAll(percolateGateway.listSchema(schemasListParams));
      logger.debug("Schema of " + postId + " is " + schemaList.size());
    }

    // this map can be converted to Map<String, Map<String, Object>> in case of segregation of
    // metadata based on schema
    final Map<String, Object> metaDataMap = new LinkedHashMap<>();
    metadataItems.parallelStream()
                 .forEach(item -> {
                   // get the schema of the metadataItem
                   final Schema schema = schemaList.stream()
                                                   .filter(s -> s.getId()
                                                                 .equals(item.getSchemaId()))
                                                   .findFirst()
                                                   .orElseThrow(() -> new CMPException("Schema not present " + item
                                                                                                                   .getSchemaId()));

                   List<MetaData> metaDatas = new ArrayList<>();
                   // identify type and label for every ext key
                   logger.info("processing schema " + item.getSchemaId());
                   metaDatas = buildMetaData(item.getExt(), schema);

                   metaDatas.parallelStream()
                            .forEach(metaData -> {

                              logger.debug(metaData);

                              if (metaData.getType()
                                          .equals(PercolateConstants.TERM)) {
                                if (metaData.getValue() instanceof List) {
                                  final List<String> terms = (List<String>) metaData.getValue();
                                  if (!terms.isEmpty()) {
                                    metaDataMap.put(metaData.getLabel(), interpretTerms(terms));
                                  }
                                } else {
                                  throw new CMPException("TERM is not an instance of List" + metaData.getValue()
                                                                                                     .getClass());
                                }
                              } else // if (metaData.getType()
                              // .equals(PercolateConstants.TEXT_AREA) || metaData.getType()
                              // .equals(
                              // PercolateConstants.SELECT))
                              {
                                metaDataMap.put(metaData.getLabel(), metaData.getValue());
                              }
                            });
                 });

    return metaDataMap;
  }

  /**
   * Get the taxonomy name from id
   * 
   * @param termList - list of taxonomy ids defined in percolate
   * @return comma separated taxonomy names after mapping
   */
  protected String interpretTerms(final List<String> termList) {
    final TermsParams termsParams = new TermsParams();
    termsParams.termIds(termList);

    return percolateGateway.listTerm(termsParams)
                           .stream()
                           .map(term -> term.getName()
                                            .trim())
                           .collect(joining(","));
  }

  /**
   * @param extMap
   * @param schema
   * @return
   */
  protected List<MetaData> buildMetaData(final Map<String, Object> extMap, final Schema schema) {
    final List<MetaData> metaDatas = new ArrayList<>();
    extMap.entrySet()
          .forEach(e -> {

            final SchemaField schemaField = schema.getFields()
                                                  .stream()
                                                  .filter(field -> field.getKey()
                                                                        .equals(e.getKey()))
                                                  .findFirst()
                                                  .orElseThrow(() -> new CMPException(
                                                      "Schema Field not present for the key " + e.getKey()));

            // filtering CWB Custom flag and URL metadata
            if (!(schemaField.getLabel()
                             .equalsIgnoreCase(customFieldFlag) || schemaField.getLabel()
                                                                              .equalsIgnoreCase(customFieldCWBUrl)))

              metaDatas.add(new MetaData(schemaField.getKey(), schemaField.getType(), schemaField.getLabel(), e
                                                                                                               .getValue()));
          });

    logger.debug("Meta data count:" + metaDatas.size());

    return metaDatas;
  }

  /**
   * Maps the percolate defined taxonomy with Disclosure understandable tags
   * 
   * @param metadata
   * @return taxonomy map after mapping
   */
  protected Map<String, Set<String>> getTaxonomyMappings(final Map<String, Object> metadata) {
    final TaxonomyMapping mappings = taxonomyRepository.fetchAllMappings();
    final Map<String, Set<String>> tagMap = new HashMap<>();

    metadata.forEach((percolateNameSpace, percolateTags) ->

    Optional.ofNullable(mappings.get(percolateNameSpace))
            .ifPresent(mappingTags -> Arrays.asList(String.valueOf(percolateTags)
                                                          .split(","))
                                            .forEach(percolateTag -> Optional.ofNullable(mappingTags.get(percolateTag))
                                                                             .ifPresent(tags -> {
                                                                               logger.debug("Taxonomy tags" + tags);
                                                                               tags.forEach((k, v) -> tagMap.merge(k,
                                                                                   new HashSet<>(Arrays.asList(v)), (v1,
                                                                                       v2) -> Stream.concat(v1.stream(),
                                                                                           v2.stream())
                                                                                                    .collect(Collectors
                                                                                                                       .toSet())));
                                                                             })))

    );
    return tagMap;
  }

  /**
   * @param postId - Percolate post id
   * @param stepData
   * @return ProductionWorkflowStepKey
   */
  protected WorkflowStepData getWorkflowStepData(final String postId, final List<WorkflowStepData> stepData) {

    return stepData.stream()
                   .filter(step -> step.getObjectId()
                                       .equals(postId))
                   .filter(WorkflowStepData::getIsCurrentStep)
                   .findFirst()
                   .orElseThrow(() -> new CMPException("Unable to find workflow step for the postId " + postId));
    // .getProductionWorkflowStepKey();
  }

  /**
   * @param postIds - Percolate post id
   * @return list of WorkflowStepData
   */
  protected List<WorkflowStepData> getCurrentWorkflowSteps(final List<String> postIds) {

    if (postIds.isEmpty())
      return Collections.emptyList();

    final WorkflowStepsParams workflowStepsParams = new WorkflowStepsParams();
    workflowStepsParams.objectIds(postIds);
    // workflowStepsParams.isCurrentStep(true);

    return percolateGateway.listWorkflowSteps(workflowStepsParams);
  }

  /**
   * @param licenses
   * @param id - license id
   * @return team name
   */
  protected String filterTeamById(final List<LicenseV5> licenses, final String id) {
    return licenses.stream()
                   .filter(team -> team.getId()
                                       .equals(id))
                   .findFirst()
                   .orElse(new LicenseV5())
                   .getName();
  }

  /**
   * @param channels
   * @param id - channel id
   * @return channel name
   */
  protected String filterChannelById(final List<ChannelV5> channels, final String id) {
    return channels.stream()
                   .filter(channel -> channel.getId()
                                             .equals(id))
                   .findFirst()
                   .orElse(new ChannelV5())
                   .getName();
  }

  /**
   * @param schemas
   * @param id - schema id
   * @return Template name
   */
  protected String filterSchemaById(final List<Schema> schemas, final String id) {
    return schemas.stream()
                  .filter(schema -> schema.getId()
                                          .equals(id))
                  .findFirst()
                  .orElse(new Schema())
                  .getName();
  }

  /**
   * @param workflows
   * @param id - workflow id
   * @return list of workflow steps
   */
  protected List<ProductionWorkflowStep> filterWorkflowStepsById(final List<ProductionWorkflow> workflows,
      final String id) {
    return workflows.stream()
                    .filter(workflow -> workflow.getId()
                                                .equals(id))
                    .findFirst()
                    .orElseThrow(() -> new CMPException("Unable to find WorkflowSteps with id " + id))
                    .getSteps();
  }

  /**
   * @param steps - workflow steps
   * @param key - workflow step key
   * @return workflow step status
   */
  protected String filterWorkflowStepByKey(final List<ProductionWorkflowStep> steps, final String key) {
    return steps.stream()
                .filter(step -> step.getKey()
                                    .equals(key))
                .findFirst()
                .orElseThrow(() -> new CMPException("Unable to find WorkflowStep with key " + key))
                .getName();
  }

  /**
   * @param steps
   * @param transitionIds
   * @param stepData
   * @return
   */
  protected Map<String, String> getAvailableTransitionNames(final List<ProductionWorkflowStep> steps,
      final List<String> transitionIds, final List<WorkflowStepData> stepData) {
    final Map<String, String> stepMap = new HashMap<>();
    transitionIds.forEach(id -> {
      final String key = stepData.stream()
                                 .filter(data -> data.getId()
                                                     .equals(id))
                                 .findFirst()
                                 .orElseThrow(() -> new CMPException("Unable to find WorkflowStep id " + id))
                                 .getProductionWorkflowStepKey();
      stepMap.put(filterWorkflowStepByKey(steps, key), id);
    });
    return stepMap;
  }

  /**
   * Method for creating wip folder in edam
   */
  @Override
  public String createWipFolder(WipFolderRequest wipr) {

    if (null == wipr)
      throw new CMPException("wip folder request is null " + wipr);
    if (wipr.isNull() || wipr.isEmpty()) {
      throw new CMPException("You have provided an empty or null value inside WipFolderRequest->  " + "percolateId:"
          + wipr.getPercolateId() + ", " + "pod:" + wipr.getPod() + ", " + "year:" + wipr.getYear() + ", "
          + "assignmentName:" + wipr.getAssignmentName());
    }

    String responseUrl = null;

    EdamWipData data = new EdamWipData();
    WipFolder wipFolder = new WipFolder();

    wipFolder.setPod(wipr.getPod());
    wipFolder.setAssignment(wipr.getAssignmentName());
    wipFolder.setPostID(wipr.getPercolateId());
    wipFolder.setYear(wipr.getYear());

    data.setWipFolder(wipFolder);
    EdamCsrfToken csrfToken = edamGateway.fetchCsrfToken();
    EdamWipDataResponse response = edamGateway.createUserWipFolder(data, csrfToken.getToken());
    if (null != response)
      responseUrl = response.getUrl();
    return responseUrl;
  }

}
