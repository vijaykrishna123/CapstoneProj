package com.capgroup.digital.ce.cmp.repositories;

import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;
import com.capgroup.digital.ce.cmp.config.TaxonomyMappingConfig;
import com.capgroup.digital.ce.cmp.dto.TaxonomyMapping;

/**
 * Last modified date: Sep 21, 2018
 * 
 * @author CONPASK
 * 
 */
@Repository
public class TaxonomyRepositoryImpl implements TaxonomyRepository {

  @Autowired
  private TaxonomyMappingConfig config;

  @Override
  @PostConstruct
  @Cacheable("mappingscache")
  public TaxonomyMapping fetchAllMappings() {
    return config.loadMappingsJson();
  }

}
