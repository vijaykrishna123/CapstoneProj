package com.capgroup.digital.ce.cmp.util;

/**
 * Last modified date: Sep 21, 2018
 * 
 * @author CONPASK
 * 
 */
public class CMPContstants {

  public static final String CWB_LINKED_FLAG_YES = "Yes";
  public static final String CWB_LINKED_FLAG_NO = "No";

  private CMPContstants() {}

}
