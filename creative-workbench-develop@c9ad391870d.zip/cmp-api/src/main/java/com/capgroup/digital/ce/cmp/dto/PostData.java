package com.capgroup.digital.ce.cmp.dto;

import java.io.Serializable;
import java.util.Map;
import java.util.Set;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * Last modified date: Sep 21, 2018
 * 
 * @author CONPASK
 * 
 */
@JsonInclude(Include.NON_NULL)
public class PostData implements Serializable {

  private static final long serialVersionUID = 5931835850956785792L;

  private String id;
  private String name;
  private String percolateUrl;
  private String template;
  private String createdAt;
  private Map<String, Object> details;
  private Map<String, Object> metaData;
  private Map<String, Set<String>> taxonomy;

  public String getId() {
    return id;
  }

  public void setId(final String id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(final String name) {
    this.name = name;
  }

  public String getPercolateUrl() {
    return percolateUrl;
  }

  public void setPercolateUrl(final String percolateUrl) {
    this.percolateUrl = percolateUrl;
  }

  public String getTemplate() {
	    return template;
  }

  public void setTemplate(final String template) {
	    this.template = template;
  }
  public Map<String, Object> getDetails() {
    return details;
  }

  public void setDetails(final Map<String, Object> details) {
    this.details = details;
  }

  public Map<String, Object> getMetaData() {
    return metaData;
  }

  public void setMetaData(final Map<String, Object> metaData) {
    this.metaData = metaData;
  }

  public Map<String, Set<String>> getTaxonomy() {
    return taxonomy;
  }

  public void setTaxonomy(final Map<String, Set<String>> taxonomy) {
    this.taxonomy = taxonomy;
  }

  public String getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(String createdAt) {
    this.createdAt = createdAt;
  }

}
