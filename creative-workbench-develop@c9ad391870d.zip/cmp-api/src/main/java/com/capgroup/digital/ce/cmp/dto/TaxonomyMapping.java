package com.capgroup.digital.ce.cmp.dto;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Last modified date: Sep 21, 2018
 * 
 * @author CONPASK
 * 
 */
public class TaxonomyMapping extends LinkedHashMap<String, Map<String, Map<String, String>>> {

  private static final long serialVersionUID = 1405639923577014786L;

}
