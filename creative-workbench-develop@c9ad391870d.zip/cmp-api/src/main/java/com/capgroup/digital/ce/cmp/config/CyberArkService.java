package com.capgroup.digital.ce.cmp.config;

import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.capgroup.digital.ce.cmp.exceptions.CMPException;
import com.capgroup.seceng.appidentity.CredentialProviderFactory;
import com.capgroup.seceng.appidentity.LoginCredentials;

@Service
public class CyberArkService {

  @Value("${cyberArk.zone}")
  public String zone;
  @Value("${cyberArk.env}")
  public String env;
  @Value("${cyberArk.resInstance}")
  public String resInstance;
  @Value("${cyberArk.resAddress}")
  public String resAddress;
  @Value("${cyberArk.technology}")
  public String technology;
  @Value("${cyberArk.cgId}")
  public String cgId;

  private static final Logger logger = LogManager.getLogger(CyberArkService.class);

  public String getKeyFromCyberArk(final String accName, final String zone, final String env, final String resInstance,
      final String resAddress, final String technology, final String cgId) {

    final List<LoginCredentials> list = CredentialProviderFactory.getCredentialProvider()
                                                                 .getCredentials(accName, cgId, zone, env, resAddress,
                                                                     resInstance, technology);
    logger.debug("LoginCredentials: " + list);
    logger.debug("accName: " + accName + ", cgId: " + cgId + ", zone: " + zone + ", env: " + env + ", resAddress: "
        + resAddress + ", resInsatance: " + resInstance + ", technology: " + technology);
    if (list != null && !list.isEmpty())
      return list.get(0)
                 .getAccountPassword();
    else
      throw new CMPException("Unable to get key details from CyberArk");
  }
}
