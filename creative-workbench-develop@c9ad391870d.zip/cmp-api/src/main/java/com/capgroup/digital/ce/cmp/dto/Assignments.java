package com.capgroup.digital.ce.cmp.dto;

import java.io.Serializable;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Last modified date: Sep 21, 2018
 * 
 * @author CONPASK
 * 
 */
@JsonInclude(Include.NON_NULL)
public class Assignments implements Serializable {

  private static final long serialVersionUID = 3673534493593300561L;

  @JsonProperty("assignments")
  private List<Post> assignmentList;

  public Assignments(final List<Post> assignments) {
    this.assignmentList = assignments;
  }

  public List<Post> getAssignments() {
    return assignmentList;
  }

  public void setAssignments(final List<Post> assignments) {
    this.assignmentList = assignments;
  }

}
