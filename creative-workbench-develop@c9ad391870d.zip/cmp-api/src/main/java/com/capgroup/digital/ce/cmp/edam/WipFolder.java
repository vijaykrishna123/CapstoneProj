package com.capgroup.digital.ce.cmp.edam;

import java.io.Serializable;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WipFolder implements Serializable {

  private static final long serialVersionUID = -2942909468084708208L;

  @JsonProperty("pod")
  protected String pod;

  @JsonProperty("assignment")
  protected String assignment;

  @JsonProperty("postID")
  protected String postID;

  @JsonProperty("year")
  protected String year;

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
  }

  public String getPod() {
    return pod;
  }

  public void setPod(final String pod) {
    this.pod = pod;
  }

  public String getAssignment() {
    return assignment;
  }

  public void setAssignment(final String assignment) {
    this.assignment = assignment;
  }

  public String getYear() {
    return year;
  }

  public void setYear(String year) {
    this.year = year;
  }

  public String getPostID() {
    return postID;
  }

  public void setPostID(String postID) {
    this.postID = postID;
  }

}

