package com.capgroup.digital.ce.cmp.edam;

import com.percolate.sdk.api.config.Endpoints;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;

interface EdamService {

  @POST(Endpoints.API_V1_PATH + "/createUserFolder")
  Call<EdamWipDataResponse> create(@Body EdamWipData wipData, @Header("Csrf-Token") String csrfToken);

  @GET("/libs/granite/csrf/token.json")
  Call<EdamCsrfToken> fetchCsrfToken(@Header("Access-Control-Allow-Origin") String accesscontrolOrigin,
      @Header("Authorization") String authorization);

}
