package com.capgroup.digital.ce.cmp.dto;

import java.io.Serializable;
import org.hibernate.validator.constraints.NotBlank;

public class Transition implements Serializable {

  private static final long serialVersionUID = -4303098802746505941L;

  @NotBlank
  String fromStatus;
  @NotBlank
  String toStatus;

  public String getFromStatus() {
    return fromStatus;
  }

  public void setFromStatus(final String fromStatus) {
    this.fromStatus = fromStatus;
  }

  public String getToStatus() {
    return toStatus;
  }

  public void setToStatus(final String toStatus) {
    this.toStatus = toStatus;
  }

}
