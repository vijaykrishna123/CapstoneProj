package com.capgroup.digital.ce.cmp.services;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import com.capgroup.digital.ce.cmp.exceptions.CMPException;
import com.capgroup.digital.ce.cmp.exceptions.PercolateException;
import com.capgroup.digital.ce.cmp.exceptions.PercolateGatewayException;
import com.percolate.sdk.api.PercolateApi;
import com.percolate.sdk.api.request.license.LicenseV5Params;
import com.percolate.sdk.api.request.metadata.MetadataParams;
import com.percolate.sdk.api.request.post.PostGetParams;
import com.percolate.sdk.api.request.post.PostListParams;
import com.percolate.sdk.api.request.schema.SchemasListParams;
import com.percolate.sdk.api.request.terms.TermsParams;
import com.percolate.sdk.api.request.users.UsersParams;
import com.percolate.sdk.api.request.workflow.WorkflowStepsParams;
import com.percolate.sdk.dto.LicenseV5;
import com.percolate.sdk.dto.LicensesV5;
import com.percolate.sdk.dto.MetadataItem;
import com.percolate.sdk.dto.MetadataList;
import com.percolate.sdk.dto.PostV5;
import com.percolate.sdk.dto.PostsV5;
import com.percolate.sdk.dto.Schema;
import com.percolate.sdk.dto.Schemas;
import com.percolate.sdk.dto.SingleMetadataItem;
import com.percolate.sdk.dto.Term;
import com.percolate.sdk.dto.Terms;
import com.percolate.sdk.dto.User;
import com.percolate.sdk.dto.Users;
import com.percolate.sdk.dto.WorkflowStepData;
import com.percolate.sdk.dto.WorkflowSteps;
import com.percolate.sdk.dto.WorkflowTransition;
import retrofit2.Response;

/**
 * Last modified date: Nov 6, 2018
 * 
 * @author conpask
 * 
 */
@Component
public class PercolateGateway {

  private static final Logger logger = LogManager.getLogger(PercolateGateway.class);

  private final PercolateApi percolateApi;

  @Autowired
  public PercolateGateway(@Qualifier("percolateApi") final PercolateApi percolateApi) {
    this.percolateApi = percolateApi;
  }

  public PercolateApi getPercolateApi() {
    return percolateApi;
  }

  public PostsV5 listPost(final PostListParams postListParams) {
    final Response<PostsV5> postResponse;
    try {
      logger.debug("Retrieving Posts for " + postListParams.getParams());
      postResponse = percolateApi.post()
                                 .list(postListParams)
                                 .execute();
    } catch (final IOException e) {
      throw new PercolateGatewayException(e);
    }

    return Optional.ofNullable(postResponse)
                   .map(response -> Optional.ofNullable(response.body())
                                            .<PercolateException>orElseThrow(() -> new PercolateException(
                                                getErrorMessage(response))))
                   .orElseThrow(() -> new CMPException("Post response object is Null"));
  }

  public PostV5 getPost(final PostGetParams postGetParams) {
    final Response<PostV5> postResponse;
    try {
      logger.debug("Retrieving Post for " + postGetParams.getParams());
      postResponse = percolateApi.post()
                                 .get(postGetParams)
                                 .execute();
    } catch (final IOException e) {
      throw new PercolateGatewayException(e);
    }

    return Optional.ofNullable(postResponse)
                   .map(response -> Optional.ofNullable(response.body())
                                            .<PercolateException>orElseThrow(() -> new PercolateException(
                                                getErrorMessage(response))))
                   .orElseThrow(() -> new CMPException("Get Post response object is Null"));
  }

  public List<User> listUser(final UsersParams usersParams) {
    final Response<Users> userResponse;
    try {
      logger.debug("Retrieving Users for " + usersParams.getParams());
      userResponse = percolateApi.users()
                                 .get(usersParams)
                                 .execute();
    } catch (final IOException e) {
      throw new PercolateGatewayException(e);
    }

    return Optional.ofNullable(Optional.ofNullable(userResponse)
                                       .map(response -> Optional.ofNullable(response.body())
                                                                .<PercolateException>orElseThrow(
                                                                    () -> new PercolateException(getErrorMessage(
                                                                        response))))
                                       .orElseThrow(() -> new CMPException("User response object is Null"))
                                       .getData())
                   .orElse(Collections.emptyList());
  }

  public List<MetadataItem> listMetadata(final MetadataParams metadataParams) {
    final Response<MetadataList> metdataResponse;
    try {
      logger.debug("Retrieving Metadata for " + metadataParams.getParams());
      metdataResponse = percolateApi.metadata()
                                    .list(metadataParams)
                                    .execute();
    } catch (final IOException e) {
      throw new PercolateGatewayException(e);
    }

    return Optional.ofNullable(Optional.ofNullable(metdataResponse)
                                       .map(response -> Optional.ofNullable(response.body())
                                                                .<PercolateException>orElseThrow(
                                                                    () -> new PercolateException(getErrorMessage(
                                                                        response))))
                                       .orElseThrow(() -> new CMPException("Metadata response object is Null"))
                                       .getData())
                   .orElse(Collections.emptyList());
  }

  public List<Schema> listSchema(final SchemasListParams schemasListParams) {
    final Response<Schemas> schemaResponse;
    try {
      logger.debug("Retrieving Schema for " + schemasListParams.getParams());
      schemaResponse = percolateApi.schemas()
                                   .list(schemasListParams)
                                   .execute();
    } catch (final IOException e) {
      throw new PercolateGatewayException(e);
    }

    return Optional.ofNullable(Optional.ofNullable(schemaResponse)
                                       .map(response -> Optional.ofNullable(response.body())
                                                                .<PercolateException>orElseThrow(
                                                                    () -> new PercolateException(getErrorMessage(
                                                                        response))))
                                       .orElseThrow(() -> new CMPException("Schema response object is Null"))
                                       .getData())
                   .orElse(Collections.emptyList());
  }

  public List<Term> listTerm(final TermsParams termsParams) {
    final Response<Terms> termsResponse;
    try {
      logger.debug("Retrieving Terms for " + termsParams.getParams());
      termsResponse = percolateApi.terms()
                                  .get(termsParams)
                                  .execute();
    } catch (final IOException e) {
      throw new PercolateGatewayException(e);
    }

    return Optional.ofNullable(Optional.ofNullable(termsResponse)
                                       .map(response -> Optional.ofNullable(response.body())
                                                                .<PercolateException>orElseThrow(
                                                                    () -> new PercolateException(getErrorMessage(
                                                                        response))))
                                       .orElseThrow(() -> new CMPException("Term response object is Null"))
                                       .getData())
                   .orElse(Collections.emptyList());
  }


  public List<WorkflowStepData> listWorkflowSteps(final WorkflowStepsParams workflowStepsParams) {
    final Response<WorkflowSteps> termsResponse;
    try {
      logger.debug("Retrieving workflow steps for " + workflowStepsParams.getParams());
      termsResponse = percolateApi.workflowSteps()
                                  .list(workflowStepsParams)
                                  .execute();
    } catch (final IOException e) {
      throw new PercolateGatewayException(e);
    }

    return Optional.ofNullable(Optional.ofNullable(termsResponse)
                                       .map(response -> Optional.ofNullable(response.body())
                                                                .<PercolateException>orElseThrow(
                                                                    () -> new PercolateException(getErrorMessage(
                                                                        response))))
                                       .orElseThrow(() -> new CMPException("WorkflowSteps response object is Null"))
                                       .getData())
                   .orElse(Collections.emptyList());
  }


  public List<LicenseV5> listLicenses(final LicenseV5Params licenseV5Params) {
    final Response<LicensesV5> licenseResponse;
    try {
      logger.debug("Retrieving licenses steps for " + licenseV5Params.getParams());
      licenseResponse = percolateApi.licenses()
                                    .get(licenseV5Params)
                                    .execute();
    } catch (final IOException e) {
      throw new PercolateGatewayException(e);
    }

    return Optional.ofNullable(Optional.ofNullable(licenseResponse)
                                       .map(response -> Optional.ofNullable(response.body())
                                                                .<PercolateException>orElseThrow(
                                                                    () -> new PercolateException(getErrorMessage(
                                                                        response))))
                                       .orElseThrow(() -> new CMPException("License response object is Null"))
                                       .getLicenses())
                   .orElse(Collections.emptyList());
  }

  public void updateMetadata(final MetadataItem metadataItem) {
    try {
      logger.debug("Updating Metadata " + metadataItem.getId() + " for post " + metadataItem.getObjectId());
      final Response<SingleMetadataItem> response = Optional.ofNullable(percolateApi.metadata()
                                                                                    .update(metadataItem)
                                                                                    .execute())
                                                            .orElseThrow(() -> new CMPException(
                                                                "Update Metadata response object is Null"));

      if (response.code() != 200) {
        throw new PercolateException(getErrorMessage(response));
      }
    } catch (final IOException e) {
      throw new PercolateGatewayException(e);
    }
  }

  public void transitAssignment(final WorkflowTransition transition) {
    try {
      logger.debug("transitioning assignment from " + transition.getFromObjectStepId() + " to " + transition
                                                                                                            .getToObjectStepId());
      final Response<Object> response = Optional.ofNullable(percolateApi.workflowSteps()
                                                                        .transit(transition)
                                                                        .execute())
                                                .orElseThrow(() -> new CMPException(
                                                    "Assignment Transition response object is Null"));

      if (response.code() != 201) {
        throw new PercolateGatewayException(getErrorMessage(response));
      }
    } catch (final IOException e) {
      throw new PercolateGatewayException(e);
    }
  }

  private <T> String getErrorMessage(final Response<T> response) {
    String errMsg = Strings.EMPTY;
    if (response.errorBody() != null) {
      try {
        errMsg = response.errorBody()
                         .string();
      } catch (final IOException e) {
        errMsg = "Unable to parse error body " + e.getMessage();
        logger.error(e);
      }
    }
    return "HTTP code:" + response.code() + ", " + errMsg;
  }
}
