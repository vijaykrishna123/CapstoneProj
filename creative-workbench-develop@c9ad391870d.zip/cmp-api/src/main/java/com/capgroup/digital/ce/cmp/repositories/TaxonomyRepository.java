package com.capgroup.digital.ce.cmp.repositories;

import com.capgroup.digital.ce.cmp.dto.TaxonomyMapping;

/**
 * Last modified date: Sep 21, 2018
 * 
 * @author CONPASK
 * 
 */
public interface TaxonomyRepository {
  TaxonomyMapping fetchAllMappings();
}
