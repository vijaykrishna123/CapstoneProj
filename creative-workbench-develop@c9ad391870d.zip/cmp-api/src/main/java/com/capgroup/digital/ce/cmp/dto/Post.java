package com.capgroup.digital.ce.cmp.dto;

import java.io.Serializable;
import java.util.Map;

/**
 * Last modified date: Sep 21, 2018
 * 
 * @author CONPASK
 * 
 */
public class Post implements Serializable {

  private static final long serialVersionUID = 2549602851748969343L;
  private String id;
  private String title;
  private String currentStatus;
  private String liveAt;
  private String channel;
  private String template;
  private String team;
  private Map<String, String> availableTransition;
  private String stateName;

  public String getId() {
    return id;
  }

  public void setId(final String id) {
    this.id = id;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(final String title) {
    this.title = title;
  }

  public String getCurrentStatus() {
    return currentStatus;
  }

  public void setCurrentStatus(final String status) {
    this.currentStatus = status;
  }

  public String getLiveAt() {
    return liveAt;
  }

  public void setLiveAt(final String liveAt) {
    this.liveAt = liveAt;
  }

  public String getChannel() {
    return channel;
  }

  public void setChannel(final String channel) {
    this.channel = channel;
  }

  public String getTemplate() {
    return template;
  }

  public void setTemplate(final String template) {
    this.template = template;
  }

  public String getTeam() {
    return team;
  }

  public void setTeam(final String team) {
    this.team = team;
  }

  public Map<String, String> getAvailableStatus() {
    return availableTransition;
  }

  public void setAvailableStatus(final Map<String, String> availableStatus) {
    this.availableTransition = availableStatus;
  }

  public String getStateName() {
    return stateName;
  }

  public void setStateName(String stateName) {
    this.stateName = stateName;
  }

}
