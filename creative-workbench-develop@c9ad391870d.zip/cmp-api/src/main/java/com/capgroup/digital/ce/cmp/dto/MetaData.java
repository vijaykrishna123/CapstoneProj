package com.capgroup.digital.ce.cmp.dto;

/**
 * Last modified date: Sep 21, 2018
 * 
 * @author CONPASK
 * 
 */
public class MetaData {

  protected String key;
  protected String type;
  protected String label;
  protected Object value;

  public MetaData(final String key, final String type, final String label, final Object value) {
    super();
    this.key = key;
    this.type = type;
    this.label = label;
    this.value = value;
  }

  public String getKey() {
    return key;
  }

  public void setKey(final String key) {
    this.key = key;
  }

  public String getType() {
    return type;
  }

  public void setType(final String type) {
    this.type = type;
  }

  public String getLabel() {
    return label;
  }

  public void setLabel(final String label) {
    this.label = label;
  }

  public Object getValue() {
    return value;
  }

  public void setValue(final Object value) {
    this.value = value;
  }

  @Override
  public String toString() {
    return "MetaData [key=" + key + ", type=" + type + ", label=" + label + ", value=" + value
        + "]";
  }

}
