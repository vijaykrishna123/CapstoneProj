package com.capgroup.digital.ce.cmp.exceptions;

/**
 * Last modified date: Sep 21, 2018
 * 
 * @author CONPASK
 * 
 */
public class PercolateException extends RuntimeException {

  private static final long serialVersionUID = -5633363342187865095L;

  public PercolateException(final String message) {
    super(message);
  }

  public PercolateException(final Throwable cause) {
    super(cause);
  }

  public PercolateException(final String message, final Throwable cause) {
    super(message, cause);
  }

  public PercolateException(final String message, final Throwable cause,
      final boolean enableSuppression, final boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }

}
