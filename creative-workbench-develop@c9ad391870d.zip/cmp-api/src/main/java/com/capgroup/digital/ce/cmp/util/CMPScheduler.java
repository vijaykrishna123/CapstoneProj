package com.capgroup.digital.ce.cmp.util;

import java.time.LocalDateTime;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import com.capgroup.digital.ce.cmp.services.CMPService;

/**
 * Last modified date: Sep 21, 2018
 * 
 * @author CONPASK
 * 
 */
@Component
public class CMPScheduler {

  private final MappingCacheEvict cacheEvict;
  private final CMPService service;
  private static final Logger logger = LogManager.getLogger(CMPScheduler.class);

  @Autowired
  public CMPScheduler(final MappingCacheEvict cacheEvict, final CMPService service) {
    this.cacheEvict = cacheEvict;
    this.service = service;
  }

  @Scheduled(fixedDelay = 7200000, initialDelay = 7200000) // 7200000 - 2 hours
  public void clearCaches() {
    logger.debug("Invalidating caches " + LocalDateTime.now());
    cacheEvict.evictAllMappingCache();
  }

  @Scheduled(cron = "${add-url.cron}")
  public void callAddUrl() {
    logger.debug("addCWBUrl API invoked:" + LocalDateTime.now());
    service.addCWBUrl();
  }
}
