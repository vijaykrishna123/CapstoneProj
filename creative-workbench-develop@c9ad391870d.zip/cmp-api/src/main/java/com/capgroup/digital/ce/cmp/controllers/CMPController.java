package com.capgroup.digital.ce.cmp.controllers;

import java.time.LocalDateTime;
import javax.validation.Valid;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.capgroup.digital.ce.cmp.dto.Assignments;
import com.capgroup.digital.ce.cmp.dto.PostData;
import com.capgroup.digital.ce.cmp.dto.Transition;
import com.capgroup.digital.ce.cmp.dto.WipFolderRequest;
import com.capgroup.digital.ce.cmp.services.CMPService;
import io.swagger.annotations.ApiOperation;


/**
 * Last modified date: Oct 2, 2018
 * 
 * @author CONPASK
 * 
 */
@RestController
@Validated
public class CMPController {

  private final CMPService service;
  private static final Logger logger = LogManager.getLogger(CMPController.class);

  @Autowired
  public CMPController(final CMPService service) {
    this.service = service;
  }

  @GetMapping("/v1/assignments")
  @ApiOperation(value = "API to get all the assigned contents for the given user", response = Assignments.class)
  public ResponseEntity<Assignments> getAssignments(@RequestParam final String search) {

    logger.debug("Search string:" + search);

    return new ResponseEntity<>(new Assignments(service.getAssignments(search)), getHeaders(), HttpStatus.OK);
  }

  @PostMapping("/v1/add-url")
  @ApiOperation(value = "API to update the percolate content metadata with CWB url")
  public ResponseEntity<Object> addCWBUrl() {

    logger.debug("addCWBUrl API invoked:" + LocalDateTime.now());
    service.addCWBUrl();
    return new ResponseEntity<>(HttpStatus.CREATED);
  }

  @PostMapping("/v1/wip-url")
  @ApiOperation(value = "API to create the WIP url in Edam")
  public ResponseEntity<String> addWIPUrl(@RequestBody WipFolderRequest wipFolder) {

    logger.debug("addWIPUrl API invoked:" + LocalDateTime.now());
    String responseUrl = service.createWipFolder(wipFolder);
    return new ResponseEntity<>(responseUrl, HttpStatus.CREATED);
  }

  @GetMapping("/v1/posts/{postId}")
  @ApiOperation(value = "API to get the content metadata from percolate")
  public ResponseEntity<PostData> getContent(@PathVariable(value = "postId") final String postId) {

    logger.info("GET posts/" + postId);

    return new ResponseEntity<>(service.getContent(postId), getHeaders(), HttpStatus.OK);
  }

  @PostMapping("/v1/assignments/transition")
  @ApiOperation(value = "API to transition the assignment workflow step in percolate")
  public ResponseEntity<Object> transition(@Valid @RequestBody final Transition transition) {

    logger.debug("Changing Assignment status from " + transition.getFromStatus() + " to " + transition.getToStatus());
    service.transitionAssignment(transition);
    return new ResponseEntity<>(HttpStatus.CREATED);
  }

  private HttpHeaders getHeaders() {
    final HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    return headers;
  }

}
