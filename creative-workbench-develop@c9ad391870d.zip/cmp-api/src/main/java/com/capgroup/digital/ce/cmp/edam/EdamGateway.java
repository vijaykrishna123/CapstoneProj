package com.capgroup.digital.ce.cmp.edam;

import java.io.IOException;
import java.util.Optional;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import com.capgroup.digital.ce.cmp.exceptions.CMPException;
import com.capgroup.digital.ce.cmp.exceptions.EdamGatewayException;
import retrofit2.Response;

@Component
public class EdamGateway {

  private static final Logger logger = LogManager.getLogger(EdamGateway.class);

  EdamApi edamApi;

  @Autowired
  public EdamGateway(@Qualifier("edamApi") final EdamApi edamApi) {
    this.edamApi = edamApi;
  }

  public EdamApi getEdamApi() {
    return edamApi;
  }

  /**
   * Method for creating wip folder in edam
   * 
   * @param wipData
   * @return
   */
  public EdamWipDataResponse createUserWipFolder(final EdamWipData wipData, String csrfToken) {

    final Response<EdamWipDataResponse> wipFolderResponse;

    try {
      logger.debug("Creating wip folder " + wipData.toString());
      wipFolderResponse = edamApi.wipFolder()
                                 .create(wipData, csrfToken)
                                 .execute();
    } catch (final IOException e) {
      throw new EdamGatewayException(e);
    }

    return Optional.ofNullable(wipFolderResponse)
                   .map(response -> Optional.ofNullable(response.body())
                                            .<CMPException>orElseThrow(() -> new CMPException(getErrorMessage(
                                                response))))
                   .orElseThrow(() -> new CMPException("Get Wip folder response object is Null"));
  }

  /**
   * Method for fetching csrf token
   * 
   * @return
   */
  public EdamCsrfToken fetchCsrfToken() {

    final Response<EdamCsrfToken> csrfToken;

    try {
      String edamCsrfTokenKey = edamApi.getApiKey();
      csrfToken = edamApi.wipFolder()
                         .fetchCsrfToken(edamCsrfTokenKey)
                         .execute();
    } catch (final IOException e) {
      throw new EdamGatewayException(e);
    }

    return Optional.ofNullable(csrfToken)
                   .map(response -> Optional.ofNullable(response.body())
                                            .<CMPException>orElseThrow(() -> new CMPException(getErrorMessage(
                                                response))))
                   .orElseThrow(() -> new CMPException("Get csrf token response object is Null"));
  }

  /**
   * Method for logging the error message
   * 
   * @param response
   * @return
   */
  private <T> String getErrorMessage(final Response<T> response) {
    String errMsg = Strings.EMPTY;
    if (response.errorBody() != null) {
      try {
        errMsg = response.errorBody()
                         .string();
      } catch (final IOException e) {
        errMsg = "Unable to parse error body " + e.getMessage();
        logger.error(e);
      }
    }
    return "HTTP code:" + response.code() + ", " + errMsg;
  }
}
