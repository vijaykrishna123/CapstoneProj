package com.capgroup.digital.ce.cmp.config;

import java.io.IOException;
import java.io.InputStream;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import com.capgroup.digital.ce.cmp.dto.TaxonomyMapping;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Last modified date: Sep 21, 2018
 * 
 * @author CONPASK
 * 
 */
@Configuration
public class TaxonomyMappingConfig {
  @Autowired
  private ObjectMapper objectMapper;
  @Value("classpath:/taxonomy-mapping.json")
  private Resource jsonResource;

  private static final Logger logger = LogManager.getLogger(TaxonomyMappingConfig.class);

  public TaxonomyMapping loadMappingsJson() {
    TaxonomyMapping mappings = new TaxonomyMapping();
    try (InputStream inputStream = jsonResource.getInputStream()) {
      mappings = objectMapper.readValue(inputStream, TaxonomyMapping.class);
      logger.debug("Loading TaxonomyMapping ->" + mappings);
    } catch (final IOException e) {
      logger.error("Error while loading taxonomy-mapping.json:", e);
      // Not rethrowing the exception because this exception makes the application fail to load
    }
    return mappings;
  }

}
