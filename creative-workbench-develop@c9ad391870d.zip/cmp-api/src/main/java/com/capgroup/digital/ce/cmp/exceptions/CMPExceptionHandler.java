package com.capgroup.digital.ce.cmp.exceptions;

import java.util.stream.Collectors;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * Last modified date: Sep 21, 2018
 * 
 * @author CONPASK
 * 
 */
@ControllerAdvice
public class CMPExceptionHandler extends ResponseEntityExceptionHandler {

  private static final Logger log = LogManager.getLogger(CMPExceptionHandler.class);

  @ExceptionHandler({CMPException.class, PercolateException.class})
  protected ResponseEntity<Object> handleCMPExceptions(final RuntimeException ex, final WebRequest request) {

    log.error(ex.getMessage(), ex);
    return handleExceptionInternal(ex, new ApiError(HttpStatus.NOT_FOUND, ex.getMessage()), getHeaders(),
        HttpStatus.NOT_FOUND, request);
  }

  @ExceptionHandler({PercolateGatewayException.class, EdamGatewayException.class})
  protected ResponseEntity<Object> handleIOException(final RuntimeException ex, final WebRequest request) {

    log.error(ex.getMessage(), ex);
    return handleExceptionInternal(ex, new ApiError(HttpStatus.BAD_GATEWAY, ex.getMessage()), getHeaders(),
        HttpStatus.BAD_GATEWAY, request);
  }

  @ExceptionHandler(Exception.class)
  protected ResponseEntity<Object> handleBadRequest(final Exception ex, final WebRequest request) {

    log.error(ex.getMessage(), ex);
    return handleExceptionInternal(ex, new ApiError(HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage()), getHeaders(),
        HttpStatus.INTERNAL_SERVER_ERROR, request);
  }

  @Override
  protected ResponseEntity<Object> handleMissingServletRequestParameter(
      final MissingServletRequestParameterException ex, final HttpHeaders headers, final HttpStatus status,
      final WebRequest request) {

    return handleExceptionInternal(ex, new ApiError(HttpStatus.BAD_REQUEST, ex.getMessage()), getHeaders(),
        HttpStatus.BAD_REQUEST, request);
  }

  @Override
  protected ResponseEntity<Object> handleMethodArgumentNotValid(final MethodArgumentNotValidException ex,
      final HttpHeaders headers, final HttpStatus status, final WebRequest request) {

    log.error(ex.getMessage());
    return handleExceptionInternal(ex, new ApiError(HttpStatus.BAD_REQUEST, ex.getBindingResult()
                                                                              .getFieldErrors()
                                                                              .stream()
                                                                              .map(field -> "'" + field.getField()
                                                                                  + "' " + field.getDefaultMessage())
                                                                              .collect(Collectors.toList())),
        getHeaders(), HttpStatus.BAD_REQUEST, request);
  }

  private HttpHeaders getHeaders() {
    final HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    return headers;
  }

}
