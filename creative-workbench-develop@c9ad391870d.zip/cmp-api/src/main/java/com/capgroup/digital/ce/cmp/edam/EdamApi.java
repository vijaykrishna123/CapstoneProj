package com.capgroup.digital.ce.cmp.edam;

import org.jetbrains.annotations.Nullable;
import com.percolate.sdk.api.PercolateApi;

public class EdamApi extends PercolateApi {

  EdamServer selectedServer;

  public EdamApi(@Nullable String edamBasicAuthKey, @Nullable final EdamServer selectedServer) {
    super(edamBasicAuthKey, selectedServer);
  }

  public EdamWipRequest wipFolder() {
    return new EdamWipRequest(this);
  }

}
