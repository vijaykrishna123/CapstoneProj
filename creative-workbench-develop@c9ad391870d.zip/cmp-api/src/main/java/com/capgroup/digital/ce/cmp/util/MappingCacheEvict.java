package com.capgroup.digital.ce.cmp.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Component;
import com.capgroup.digital.ce.cmp.config.TaxonomyMappingConfig;

/**
 * Last modified date: Sep 21, 2018
 * 
 * @author CONPASK
 * 
 */
@Component
public class MappingCacheEvict {

  private final TaxonomyMappingConfig config;

  @Autowired
  public MappingCacheEvict(final TaxonomyMappingConfig config) {
    this.config = config;
  }

  @CacheEvict(cacheNames = "mappingscache", allEntries = true)
  public void evictAllMappingCache() {
    // reloads the Cache
    config.loadMappingsJson();
  }
}
