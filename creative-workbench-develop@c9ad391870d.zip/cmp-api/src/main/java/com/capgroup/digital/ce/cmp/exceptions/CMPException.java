package com.capgroup.digital.ce.cmp.exceptions;

/**
 * Last modified date: Sep 21, 2018
 * 
 * @author CONPASK
 * 
 */
public class CMPException extends RuntimeException {

  private static final long serialVersionUID = -5293338661336266729L;

  public CMPException(final String message) {
    super(message);
  }

  public CMPException(final Throwable cause) {
    super(cause);
  }

  public CMPException(final String message, final Throwable cause) {
    super(message, cause);
  }

  public CMPException(final String message, final Throwable cause, final boolean enableSuppression,
      final boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }

}
