package com.capgroup.digital.ce.cmp.services;

import java.util.List;
import com.capgroup.digital.ce.cmp.dto.Post;
import com.capgroup.digital.ce.cmp.dto.PostData;
import com.capgroup.digital.ce.cmp.dto.Transition;
import com.capgroup.digital.ce.cmp.dto.WipFolderRequest;

/**
 * Last modified date: Oct 2, 2018
 * 
 * @author CONPASK
 * 
 */
public interface CMPService {

  /**
   * Get all the CMP assignments for the given user
   * 
   * @param search - user email id
   * @return List of CMP Post object
   */
  List<Post> getAssignments(final String search);

  /**
   * Get Post details for the given post id
   * 
   * @param postId - CMP post id
   * @return CMP PostData object
   */
  PostData getContent(final String postId);

  /**
   * Adds auto-generated CWB url for every newly created posts in CMP
   */
  void addCWBUrl();

  /**
   * Method for creating the wip folder in edam
   * 
   * @param wipFolder
   * @return
   */
  String createWipFolder(WipFolderRequest wipFolder);

  /**
   * Method to transition the assignment workflow step in percolate
   * 
   * @param transition
   */
  void transitionAssignment(Transition transition);

}
