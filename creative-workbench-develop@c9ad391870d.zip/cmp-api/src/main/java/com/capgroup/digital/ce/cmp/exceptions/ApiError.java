package com.capgroup.digital.ce.cmp.exceptions;

import java.util.Arrays;
import java.util.List;
import org.springframework.http.HttpStatus;

/**
 * Last modified date: Sep 21, 2018
 * 
 * @author CONPASK
 * 
 */
public class ApiError {

  private final HttpStatus status;
  private final List<String> errors;

  public ApiError(final HttpStatus status, final List<String> errors) {
    super();
    this.status = status;
    this.errors = errors;
  }

  public ApiError(final HttpStatus status, final String error) {
    super();
    this.status = status;
    errors = Arrays.asList(error);
  }

  public HttpStatus getStatus() {
    return status;
  }

  public List<String> getErrors() {
    return errors;
  }

}
