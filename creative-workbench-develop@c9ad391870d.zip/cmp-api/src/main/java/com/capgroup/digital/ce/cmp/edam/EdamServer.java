package com.capgroup.digital.ce.cmp.edam;

import com.percolate.sdk.api.config.PercolateServer;

public class EdamServer extends PercolateServer {

  public EdamServer(String transport, String domain, boolean isEdamContext) {
    super(transport, domain, true);
  }

}
