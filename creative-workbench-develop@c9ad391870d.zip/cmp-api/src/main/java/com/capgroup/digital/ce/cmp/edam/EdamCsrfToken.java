package com.capgroup.digital.ce.cmp.edam;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.percolate.sdk.dto.PostV5Data;
import com.percolate.sdk.dto.PostV5Include;
import com.percolate.sdk.dto.V5Meta;
import com.percolate.sdk.interfaces.HasExtraFields;


@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)

public class EdamCsrfToken implements Serializable  {
  

  private static final long serialVersionUID = 4435737568483765895L;

  @JsonProperty("token")
  protected String token;

  public String getToken() {
    return token;
  }

  public void setToken(String token) {
    this.token = token;
  }



}
