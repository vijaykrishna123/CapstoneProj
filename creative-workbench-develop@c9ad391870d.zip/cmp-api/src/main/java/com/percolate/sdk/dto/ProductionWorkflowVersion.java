package com.percolate.sdk.dto;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Last modified date: Sep 25, 2018
 * 
 * @author conpask
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductionWorkflowVersion implements Serializable {

  private static final long serialVersionUID = -3017198673354324959L;
  @JsonProperty("latest_version_id")
  private Object latestVersionId;
  @JsonProperty("provenance_id")
  private String provenanceId;
  @JsonProperty("version_id")
  private String versionId;
  @JsonProperty("previous_version_id")
  private Object previousVersionId;

  @JsonProperty("latest_version_id")
  public Object getLatestVersionId() {
    return latestVersionId;
  }

  @JsonProperty("latest_version_id")
  public void setLatestVersionId(final Object latestVersionId) {
    this.latestVersionId = latestVersionId;
  }

  @JsonProperty("provenance_id")
  public String getProvenanceId() {
    return provenanceId;
  }

  @JsonProperty("provenance_id")
  public void setProvenanceId(final String provenanceId) {
    this.provenanceId = provenanceId;
  }

  @JsonProperty("version_id")
  public String getVersionId() {
    return versionId;
  }

  @JsonProperty("version_id")
  public void setVersionId(final String versionId) {
    this.versionId = versionId;
  }

  @JsonProperty("previous_version_id")
  public Object getPreviousVersionId() {
    return previousVersionId;
  }

  @JsonProperty("previous_version_id")
  public void setPreviousVersionId(final Object previousVersionId) {
    this.previousVersionId = previousVersionId;
  }

}
