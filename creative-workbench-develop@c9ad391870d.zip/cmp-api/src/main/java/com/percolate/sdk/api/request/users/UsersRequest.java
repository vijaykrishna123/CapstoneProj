package com.percolate.sdk.api.request.users;

import com.percolate.sdk.api.PercolateApi;
import com.percolate.sdk.api.utils.RetrofitApiFactory;
import com.percolate.sdk.dto.ChangePasswordError;
import com.percolate.sdk.dto.SingleUser;
import com.percolate.sdk.dto.Users;
import org.jetbrains.annotations.NotNull;
import retrofit2.Call;

/**
 * Users request proxy.
 */
@SuppressWarnings("unused")
public class UsersRequest {

    private UsersService service;

    public UsersRequest(@NotNull PercolateApi context) {
        this.service = new RetrofitApiFactory(context).getService(UsersService.class);
    }

    /**
     * Query "me" endpoint.
     *
     * @return {@link Call} object.
     */
    public Call<SingleUser> me() {
        return service.me();
    }

    /**
     * Query users endpoint.
     *
     * @param params API params.
     * @return {@link Call} object.
     */
    public Call<Users> get(@NotNull final UsersParams params) {
        return service.get(params.getParams());
    }

    /**
     * Update user password.
     *
     * @param params API params.
     * @return {@link Call} object.
     */
    public Call<ChangePasswordError> changePassword(@NotNull final UsersUpdatePasswordParams params) {
        return service.changePassword(params.getUserId(), params.getParams());
    }
}
