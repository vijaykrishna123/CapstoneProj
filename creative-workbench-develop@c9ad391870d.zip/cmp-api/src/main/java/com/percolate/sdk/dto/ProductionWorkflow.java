package com.percolate.sdk.dto;

import java.io.Serializable;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Last modified date: Sep 25, 2018
 * 
 * @author conpask
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductionWorkflow implements Serializable {

  private static final long serialVersionUID = -5262784910192719390L;

  @JsonProperty("possible_initial_step_keys")
  private List<String> possibleInitialStepKeys = null;
  @JsonProperty("version")
  private ProductionWorkflowVersion version;
  @JsonProperty("scope_id")
  private String scopeId;
  @JsonProperty("name")
  private String name;
  @JsonProperty("steps")
  private List<ProductionWorkflowStep> steps = null;
  @JsonProperty("type")
  private String type;
  @JsonProperty("id")
  private String id;
  @JsonProperty("updated_at")
  private String updatedAt;

  @JsonProperty("possible_initial_step_keys")
  public List<String> getPossibleInitialStepKeys() {
    return possibleInitialStepKeys;
  }

  @JsonProperty("possible_initial_step_keys")
  public void setPossibleInitialStepKeys(final List<String> possibleInitialStepKeys) {
    this.possibleInitialStepKeys = possibleInitialStepKeys;
  }

  @JsonProperty("version")
  public ProductionWorkflowVersion getVersion() {
    return version;
  }

  @JsonProperty("version")
  public void setVersion(final ProductionWorkflowVersion version) {
    this.version = version;
  }

  @JsonProperty("scope_id")
  public String getScopeId() {
    return scopeId;
  }

  @JsonProperty("scope_id")
  public void setScopeId(final String scopeId) {
    this.scopeId = scopeId;
  }

  @JsonProperty("name")
  public String getName() {
    return name;
  }

  @JsonProperty("name")
  public void setName(final String name) {
    this.name = name;
  }

  @JsonProperty("steps")
  public List<ProductionWorkflowStep> getSteps() {
    return steps;
  }

  @JsonProperty("steps")
  public void setSteps(final List<ProductionWorkflowStep> steps) {
    this.steps = steps;
  }

  @JsonProperty("type")
  public String getType() {
    return type;
  }

  @JsonProperty("type")
  public void setType(final String type) {
    this.type = type;
  }

  @JsonProperty("id")
  public String getId() {
    return id;
  }

  @JsonProperty("id")
  public void setId(final String id) {
    this.id = id;
  }

  @JsonProperty("updated_at")
  public String getUpdatedAt() {
    return updatedAt;
  }

  @JsonProperty("updated_at")
  public void setUpdatedAt(final String updatedAt) {
    this.updatedAt = updatedAt;
  }

}
