package com.percolate.sdk.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.percolate.sdk.interfaces.HasExtraFields;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PostV5Include implements Serializable, HasExtraFields {

  private static final long serialVersionUID = 3023521241837003165L;

  @JsonProperty("platform")
  protected List<Platform> platform;

  @JsonProperty("channel")
  protected List<ChannelV5> channel;

  @JsonProperty("schema")
  protected List<Schema> schema;

  @JsonProperty("production_workflow")
  protected List<ProductionWorkflow> productionWorkflow;

  @JsonIgnore
  protected Map<String, Object> extraFields = new HashMap<>();

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
  }

  public List<ChannelV5> getChannel() {
    return channel;
  }

  public void setChannel(final List<ChannelV5> channel) {
    this.channel = channel;
  }

  public List<Platform> getPlatform() {
    return platform;
  }

  public void setPlatform(final List<Platform> platform) {
    this.platform = platform;
  }

  public List<Schema> getSchema() {
    return schema;
  }

  public void setProductionWorkflow(final List<ProductionWorkflow> productionWorkflow) {
    this.productionWorkflow = productionWorkflow;
  }

  public List<ProductionWorkflow> getProductionWorkflow() {
    return productionWorkflow;
  }

  public void setSchema(final List<Schema> schema) {
    this.schema = schema;
  }

  @Override
  public Map<String, Object> getExtraFields() {
    if (extraFields == null) {
      extraFields = new HashMap<>();
    }
    return extraFields;
  }

  @Override
  @JsonAnySetter
  public void putExtraField(final String key, final Object value) {
    getExtraFields().put(key, value);
  }
}
