package com.percolate.sdk.dto;

import com.fasterxml.jackson.annotation.*;
import com.percolate.sdk.interfaces.HasExtraFields;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

@SuppressWarnings("UnusedDeclaration")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FacebookMonitoringXObj implements Serializable, HasExtraFields {

    private static final long serialVersionUID = -1729202563494110505L;

    @JsonProperty("id")
    protected String id;

    @JsonProperty("body")
    protected String body;

    @JsonProperty("created_at")
    protected String createdAt;

    @JsonProperty("num_children")
    protected Integer numChildren;

    @JsonProperty("num_likes")
    protected Integer numLikes;

    @JsonProperty("num_shares")
    protected Integer numShares;

    @JsonProperty("parent_id")
    protected String parentId;

    @JsonProperty("permalink")
    protected String permalink;

    @JsonProperty("picture")
    protected String picture;

    @JsonProperty("thumbnail")
    protected String thumbnail;

    @JsonProperty("type")
    protected String type;

    @JsonProperty("user")
    protected FacebookMonitoringUser user;

    @JsonIgnore
    protected Map<String, Object> extraFields = new HashMap<>();

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public Integer getNumChildren() {
        return numChildren;
    }

    public void setNumChildren(Integer numChildren) {
        this.numChildren = numChildren;
    }

    public Integer getNumLikes() {
        return numLikes;
    }

    public void setNumLikes(Integer numLikes) {
        this.numLikes = numLikes;
    }

    public Integer getNumShares() {
        return numShares;
    }

    public void setNum_shares(Integer numShares) {
        this.numShares = numShares;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getPermalink() {
        return permalink;
    }

    public void setPermalink(String permalink) {
        this.permalink = permalink;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public FacebookMonitoringUser getUser() {
        return user;
    }

    public void setUser(FacebookMonitoringUser user) {
        this.user = user;
    }


    @Override
    public Map<String, Object> getExtraFields() {
        if(extraFields == null) {
            extraFields = new HashMap<>();
        }
        return extraFields;
    }

    @Override
    @JsonAnySetter
    public void putExtraField(String key, Object value) {
        getExtraFields().put(key, value);
    }
}
