package com.percolate.sdk.api.request.workflow;

import org.jetbrains.annotations.NotNull;
import com.percolate.sdk.api.PercolateApi;
import com.percolate.sdk.api.utils.RetrofitApiFactory;
import com.percolate.sdk.dto.WorkflowSteps;
import com.percolate.sdk.dto.WorkflowTransition;
import retrofit2.Call;


/**
 * Last modified date: Sep 25, 2018
 * 
 * @author conpask
 * 
 */
public class WorkflowStepsRequest {

  private final WorkflowStepsService service;

  public WorkflowStepsRequest(@NotNull final PercolateApi context) {
    this.service = new RetrofitApiFactory(context).getService(WorkflowStepsService.class);
  }

  /**
   * Query users endpoint.
   *
   * @param params API params.
   * @return {@link Call} object.
   */
  public Call<WorkflowSteps> list(@NotNull final WorkflowStepsParams params) {
    return service.get(params.getParams());
  }

  public Call<Object> transit(final WorkflowTransition transition) {
    return service.transit(transition);
  }
}
