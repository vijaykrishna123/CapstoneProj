package com.percolate.sdk.dto;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Last modified date: Sep 25, 2018
 * 
 * @author conpask
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductionWorkflowStep implements Serializable {

  private static final long serialVersionUID = 6576213538845287493L;

  @JsonProperty("duration")
  private Object duration;
  @JsonProperty("type")
  private String type;
  @JsonProperty("name")
  private String name;
  @JsonProperty("key")
  private String key;
  @JsonProperty("description")
  private String description;

  @JsonProperty("duration")
  public Object getDuration() {
    return duration;
  }

  @JsonProperty("duration")
  public void setDuration(final Object duration) {
    this.duration = duration;
  }

  @JsonProperty("type")
  public String getType() {
    return type;
  }

  @JsonProperty("type")
  public void setType(final String type) {
    this.type = type;
  }

  @JsonProperty("name")
  public String getName() {
    return name;
  }

  @JsonProperty("name")
  public void setName(final String name) {
    this.name = name;
  }

  @JsonProperty("key")
  public String getKey() {
    return key;
  }

  @JsonProperty("key")
  public void setKey(final String key) {
    this.key = key;
  }

  @JsonProperty("description")
  public String getDescription() {
    return description;
  }

  @JsonProperty("description")
  public void setDescription(final String description) {
    this.description = description;
  }

}
