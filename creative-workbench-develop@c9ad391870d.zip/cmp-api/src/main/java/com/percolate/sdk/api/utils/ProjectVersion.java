package com.percolate.sdk.api.utils;

  public class ProjectVersion {
      public static final String VERSION = "1.0.42-4-g2552822";
}