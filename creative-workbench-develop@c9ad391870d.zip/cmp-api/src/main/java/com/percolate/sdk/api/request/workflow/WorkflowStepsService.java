package com.percolate.sdk.api.request.workflow;

import java.util.Map;
import com.percolate.sdk.api.config.Endpoints;
import com.percolate.sdk.dto.WorkflowSteps;
import com.percolate.sdk.dto.WorkflowTransition;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.QueryMap;

/**
 * Last modified date: Sep 25, 2018
 * 
 * @author conpask
 * 
 */
public interface WorkflowStepsService {

  @GET(Endpoints.API_V5_PATH + "/object_step/")
  Call<WorkflowSteps> get(@QueryMap Map<String, Object> params);

  @POST(Endpoints.API_V5_PATH + "/production_workflow_transition/")
  Call<Object> transit(@Body WorkflowTransition transition);
}
