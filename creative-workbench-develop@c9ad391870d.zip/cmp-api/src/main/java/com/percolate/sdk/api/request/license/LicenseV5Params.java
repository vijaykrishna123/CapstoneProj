package com.percolate.sdk.api.request.license;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import com.percolate.sdk.enums.LicenseStatus;

/**
 * Parameters for LicenseV5 request.
 */
public class LicenseV5Params {
  private final Map<String, Object> params = new HashMap<>();

  public LicenseV5Params(final String tenantId) {
    params.put("tenant_id", tenantId);
  }

  public LicenseV5Params(final List<String> licenseIds) {
    params.put("ids", StringUtils.join(licenseIds, ","));
  }

  public LicenseV5Params limit(final int limit) {
    params.put("limit", limit);
    return this;
  }

  public LicenseV5Params offset(final int offset) {
    params.put("offset", offset);
    return this;
  }

  public LicenseV5Params statuses(final LicenseStatus status) {
    params.put("statuses", status.toString()
        .toLowerCase());
    return this;
  }

  public Map<String, Object> getParams() {
    return params;
  }
}
