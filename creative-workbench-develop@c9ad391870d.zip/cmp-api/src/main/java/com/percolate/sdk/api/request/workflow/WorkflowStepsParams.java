package com.percolate.sdk.api.request.workflow;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;

/**
 * Last modified date: Sep 25, 2018
 * 
 * @author conpask
 * 
 */
public class WorkflowStepsParams {
  private final Map<String, Object> params = new HashMap<>();

  public WorkflowStepsParams() {}

  public WorkflowStepsParams objectIds(final List<String> ids) {
    params.put("object_ids", StringUtils.join(ids, ","));
    return this;
  }

  public WorkflowStepsParams isCurrentStep(final boolean flag) {
    params.put("is_current_step", flag);
    return this;
  }

  public Map<String, Object> getParams() {
    return params;
  }
}
